// Auto Generated Code by Tool [JsonToBean]
// Author Mail: weicheng.xi@emc.com
// Version: 1.0.0

import java.io.Serializable;

/**
 * 
 * @author weichx
 * 
 * @date 2015/06/04 17:13:57
 * 
 */
public class Override implements Serializable {

	/** eg: Mount Copy **/
	private String name;
	private OverrideOptions options;
	/** eg: e89ddb6a-d905-4c42-8bc1-b963ed359376 **/
	private String id;
	/** eg: true **/
	private String enabled;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
		
	public OverrideOptions getOptions() {
		return options;
	}

	public void setOptions(OverrideOptions options) {
		this.options = options;
	}
		
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
		
	public String getEnabled() {
		return enabled;
	}

	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}
		
}
