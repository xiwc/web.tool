// Auto Generated Code by Tool [JsonToBean]
// Author Mail: weicheng.xi@emc.com
// Version: 1.0.0

import java.io.Serializable;

/**
 * 
 * @author weichx
 * 
 * @date 2015/06/04 17:13:57
 * 
 */
public class MountPhase implements Serializable {

	private Options options;
	/** eg: true **/
	private String enabled;
	
	public Options getOptions() {
		return options;
	}

	public void setOptions(Options options) {
		this.options = options;
	}
		
	public String getEnabled() {
		return enabled;
	}

	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}
		
}
