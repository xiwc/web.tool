// Auto Generated Code by Tool [JsonToBean]
// Author Mail: weicheng.xi@emc.com
// Version: 1.0.0

import java.io.Serializable;

/**
 * 
 * @author weichx
 * 
 * @date 2015/06/04 17:13:57
 * 
 */
public class ScheduleOptions implements Serializable {

	/** eg: 1440 **/
	private String rpoValueInMinute;
	/** eg: true/false **/
	private String rpoMonitor;
	
	public String getRpoValueInMinute() {
		return rpoValueInMinute;
	}

	public void setRpoValueInMinute(String rpoValueInMinute) {
		this.rpoValueInMinute = rpoValueInMinute;
	}
		
	public String getRpoMonitor() {
		return rpoMonitor;
	}

	public void setRpoMonitor(String rpoMonitor) {
		this.rpoMonitor = rpoMonitor;
	}
		
}
