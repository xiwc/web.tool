// Auto Generated Code by Tool [JsonToBean]
// Author Mail: weicheng.xi@emc.com
// Version: 1.0.0

import java.io.Serializable;

/**
 * 
 * @author weichx
 * 
 * @date 2015/06/04 17:13:57
 * 
 */
public class ServicePlan implements Serializable {

	/** eg: Bronze **/
	private String planType;
	/** eg: eric_bronze_plan **/
	private String planName;
	/** eg: modified description on one plan **/
	private String description;
	private UnmountPreviousCopyPhase unmountPreviousCopyPhase;
	private List<Dataset> datasets;
	/** eg: false **/
	private String isBuiltIn;
	private DiscoveryPhaseSpec discoveryPhaseSpec;
	/** eg: 2 **/
	private String version;
	/** eg: true **/
	private String enabled;
	private MountPhase mountPhase;
	private ReplicationPhaseSpec replicationPhaseSpec;
	/** eg: 7a696f98-b870-4a73-ad6a-283105e9c45c **/
	private String id;
	/** eg: eric_bronze_plan **/
	private String planDisplayName;
	
	public String getPlanType() {
		return planType;
	}

	public void setPlanType(String planType) {
		this.planType = planType;
	}
		
	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}
		
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
		
	public UnmountPreviousCopyPhase getUnmountPreviousCopyPhase() {
		return unmountPreviousCopyPhase;
	}

	public void setUnmountPreviousCopyPhase(UnmountPreviousCopyPhase unmountPreviousCopyPhase) {
		this.unmountPreviousCopyPhase = unmountPreviousCopyPhase;
	}
		
	public List<Dataset> getDatasets() {
		return datasets;
	}

	public void setDatasets(List<Dataset> datasets) {
		this.datasets = datasets;
	}
		
	public String getIsBuiltIn() {
		return isBuiltIn;
	}

	public void setIsBuiltIn(String isBuiltIn) {
		this.isBuiltIn = isBuiltIn;
	}
		
	public DiscoveryPhaseSpec getDiscoveryPhaseSpec() {
		return discoveryPhaseSpec;
	}

	public void setDiscoveryPhaseSpec(DiscoveryPhaseSpec discoveryPhaseSpec) {
		this.discoveryPhaseSpec = discoveryPhaseSpec;
	}
		
	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}
		
	public String getEnabled() {
		return enabled;
	}

	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}
		
	public MountPhase getMountPhase() {
		return mountPhase;
	}

	public void setMountPhase(MountPhase mountPhase) {
		this.mountPhase = mountPhase;
	}
		
	public ReplicationPhaseSpec getReplicationPhaseSpec() {
		return replicationPhaseSpec;
	}

	public void setReplicationPhaseSpec(ReplicationPhaseSpec replicationPhaseSpec) {
		this.replicationPhaseSpec = replicationPhaseSpec;
	}
		
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
		
	public String getPlanDisplayName() {
		return planDisplayName;
	}

	public void setPlanDisplayName(String planDisplayName) {
		this.planDisplayName = planDisplayName;
	}
		
}
