// Auto Generated Code by Tool [JsonToBean]
// Author Mail: weicheng.xi@emc.com
// Version: 1.0.0

import java.io.Serializable;

/**
 * 
 * @author weichx
 * 
 * @date 2015/06/04 17:13:57
 * 
 */
public class OverrideOptions implements Serializable {

	/** eg: read-only **/
	private String accessType;
	/** eg: 844BC0C8-2252-49E5-8663-26473257D993 **/
	private String vCenterUuid;
	/** eg: true **/
	private String resignature;
	/** eg: false **/
	private String clusterMount;
	/** eg: physical **/
	private String accessMode;
	
	public String getAccessType() {
		return accessType;
	}

	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}
		
	public String getVCenterUuid() {
		return vCenterUuid;
	}

	public void setVCenterUuid(String vCenterUuid) {
		this.vCenterUuid = vCenterUuid;
	}
		
	public String getResignature() {
		return resignature;
	}

	public void setResignature(String resignature) {
		this.resignature = resignature;
	}
		
	public String getClusterMount() {
		return clusterMount;
	}

	public void setClusterMount(String clusterMount) {
		this.clusterMount = clusterMount;
	}
		
	public String getAccessMode() {
		return accessMode;
	}

	public void setAccessMode(String accessMode) {
		this.accessMode = accessMode;
	}
		
}
