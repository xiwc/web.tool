// Auto Generated Code by Tool [JsonToBean]
// Author Mail: weicheng.xi@emc.com
// Version: 1.0.0

import java.io.Serializable;

/**
 * 
 * @author weichx
 * 
 * @date 2015/06/04 17:13:57
 * 
 */
public class Dataset implements Serializable {

	private Datastore datastore;
	private DatasetOptions options;
	/** eg: e07fb9f4-0c04-4d52-ac8f-f1ce4aab9da8 **/
	private String id;
	private Override override;
	/** eg: datastore **/
	private String type;
	
	public Datastore getDatastore() {
		return datastore;
	}

	public void setDatastore(Datastore datastore) {
		this.datastore = datastore;
	}
		
	public DatasetOptions getOptions() {
		return options;
	}

	public void setOptions(DatasetOptions options) {
		this.options = options;
	}
		
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
		
	public Override getOverride() {
		return override;
	}

	public void setOverride(Override override) {
		this.override = override;
	}
		
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
		
}
