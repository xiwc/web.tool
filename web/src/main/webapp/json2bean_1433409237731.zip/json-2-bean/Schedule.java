// Auto Generated Code by Tool [JsonToBean]
// Author Mail: weicheng.xi@emc.com
// Version: 1.0.0

import java.io.Serializable;

/**
 * 
 * @author weichx
 * 
 * @date 2015/06/04 17:13:57
 * 
 */
public class Schedule implements Serializable {

	/** eg: *:*:*:*:0:5:0 **/
	private String scheduleExpression;
	private ScheduleOptions options;
	
	public String getScheduleExpression() {
		return scheduleExpression;
	}

	public void setScheduleExpression(String scheduleExpression) {
		this.scheduleExpression = scheduleExpression;
	}
		
	public ScheduleOptions getOptions() {
		return options;
	}

	public void setOptions(ScheduleOptions options) {
		this.options = options;
	}
		
}
