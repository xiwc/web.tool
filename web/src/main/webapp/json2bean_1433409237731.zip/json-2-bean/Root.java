// Auto Generated Code by Tool [JsonToBean]
// Author Mail: weicheng.xi@emc.com
// Version: 1.0.0

import java.io.Serializable;

/**
 * 
 * @author weichx
 * 
 * @date 2015/06/04 17:13:57
 * 
 */
public class Root implements Serializable {

	private ServicePlan servicePlan;
	
	public ServicePlan getServicePlan() {
		return servicePlan;
	}

	public void setServicePlan(ServicePlan servicePlan) {
		this.servicePlan = servicePlan;
	}
		
}
