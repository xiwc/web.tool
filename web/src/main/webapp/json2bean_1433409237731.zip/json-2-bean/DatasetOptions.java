// Auto Generated Code by Tool [JsonToBean]
// Author Mail: weicheng.xi@emc.com
// Version: 1.0.0

import java.io.Serializable;

/**
 * 
 * @author weichx
 * 
 * @date 2015/06/04 17:13:57
 * 
 */
public class DatasetOptions implements Serializable {

	/** eg: ds:///vmfs/volumes/545aa3db-ffb16c39-38e1-d072dc5a4584/ **/
	private String datastore;
	/** eg: dd7096ff-1417-49af-acff-d9eb68312617 **/
	private String vCenterServer;
	
	public String getDatastore() {
		return datastore;
	}

	public void setDatastore(String datastore) {
		this.datastore = datastore;
	}
		
	public String getVCenterServer() {
		return vCenterServer;
	}

	public void setVCenterServer(String vCenterServer) {
		this.vCenterServer = vCenterServer;
	}
		
}
