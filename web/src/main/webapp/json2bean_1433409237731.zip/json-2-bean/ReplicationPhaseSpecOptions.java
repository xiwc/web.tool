// Auto Generated Code by Tool [JsonToBean]
// Author Mail: weicheng.xi@emc.com
// Version: 1.0.0

import java.io.Serializable;

/**
 * 
 * @author weichx
 * 
 * @date 2015/06/04 17:13:57
 * 
 */
public class ReplicationPhaseSpecOptions implements Serializable {

	/** eg: true/false **/
	private String isIncludeVMDisksForCopy;
	/** eg: VM/CRASH **/
	private String appConsistency;
	/** eg: 4 **/
	private String maxSimultaneousVmSnapshots;
	/** eg: 2 **/
	private String numberOfCopiesForExpire;
	
	public String getIsIncludeVMDisksForCopy() {
		return isIncludeVMDisksForCopy;
	}

	public void setIsIncludeVMDisksForCopy(String isIncludeVMDisksForCopy) {
		this.isIncludeVMDisksForCopy = isIncludeVMDisksForCopy;
	}
		
	public String getAppConsistency() {
		return appConsistency;
	}

	public void setAppConsistency(String appConsistency) {
		this.appConsistency = appConsistency;
	}
		
	public String getMaxSimultaneousVmSnapshots() {
		return maxSimultaneousVmSnapshots;
	}

	public void setMaxSimultaneousVmSnapshots(String maxSimultaneousVmSnapshots) {
		this.maxSimultaneousVmSnapshots = maxSimultaneousVmSnapshots;
	}
		
	public String getNumberOfCopiesForExpire() {
		return numberOfCopiesForExpire;
	}

	public void setNumberOfCopiesForExpire(String numberOfCopiesForExpire) {
		this.numberOfCopiesForExpire = numberOfCopiesForExpire;
	}
		
}
