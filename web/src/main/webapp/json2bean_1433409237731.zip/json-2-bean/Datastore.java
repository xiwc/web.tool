// Auto Generated Code by Tool [JsonToBean]
// Author Mail: weicheng.xi@emc.com
// Version: 1.0.0

import java.io.Serializable;

/**
 * 
 * @author weichx
 * 
 * @date 2015/06/04 17:13:57
 * 
 */
public class Datastore implements Serializable {

	/** eg: datastore-2162 **/
	private String datastoreVcenterId;
	/** eg: ds:///vmfs/volumes/545aa3db-ffb16c39-38e1-d072dc5a4584/ **/
	private String datastoreUrl;
	/** eg: vsi_sh_dev_dc **/
	private String datacenterName;
	/** eg: Natasha_CG_CLR_2 **/
	private String name;
	/** eg: b7459be9-1852-404d-94fc-bfe35989b937 **/
	private String id;
	/** eg: 10.102.7.17 **/
	private String vcenterName;
	
	public String getDatastoreVcenterId() {
		return datastoreVcenterId;
	}

	public void setDatastoreVcenterId(String datastoreVcenterId) {
		this.datastoreVcenterId = datastoreVcenterId;
	}
		
	public String getDatastoreUrl() {
		return datastoreUrl;
	}

	public void setDatastoreUrl(String datastoreUrl) {
		this.datastoreUrl = datastoreUrl;
	}
		
	public String getDatacenterName() {
		return datacenterName;
	}

	public void setDatacenterName(String datacenterName) {
		this.datacenterName = datacenterName;
	}
		
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
		
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
		
	public String getVcenterName() {
		return vcenterName;
	}

	public void setVcenterName(String vcenterName) {
		this.vcenterName = vcenterName;
	}
		
}
